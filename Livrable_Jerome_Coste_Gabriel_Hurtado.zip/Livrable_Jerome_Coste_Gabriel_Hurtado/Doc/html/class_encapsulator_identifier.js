var class_encapsulator_identifier =
[
    [ "EncapsulatorIdentifier", "class_encapsulator_identifier.html#a9f00e0a724afb69a612363b0d551fd60", null ],
    [ "setLeftDelimiter", "class_encapsulator_identifier.html#a3a3bd8ce1258ef2c4a444fd3aaba7433", null ],
    [ "setRightDelimiter", "class_encapsulator_identifier.html#a1fa934366dd6aa25ac6bf8a7512ea521", null ],
    [ "WordGuesser", "class_encapsulator_identifier.html#ab4dacbe95fb9ece2dea997ea2842b242", null ],
    [ "WordPosition", "class_encapsulator_identifier.html#a7bb4b04f1fe391ce4b58827f5e2f15f5", null ]
];