var class_litterale_exception =
[
    [ "LitteraleException", "class_litterale_exception.html#ae983b54f04c8a3627dcd829250aeb755", null ],
    [ "getInfo", "class_litterale_exception.html#ae79462e23d8e1d00e63e522ad49c4924", null ],
    [ "getType", "class_litterale_exception.html#aff7f854bd90572da40b12f8c335eeae5", null ],
    [ "what", "class_litterale_exception.html#a466f617ec183f14a269c5476d09ef7d7", null ]
];