var classop__pile_1_1_operateur_pile =
[
    [ "OperateurPile", "classop__pile_1_1_operateur_pile.html#af5996c28ef0d221d1b1e71bfbf992814", null ],
    [ "getCopy", "classop__pile_1_1_operateur_pile.html#a4c128eab580fe3819e4464923f1c7fb2", null ]
];