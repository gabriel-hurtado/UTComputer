var class_word_identifier =
[
    [ "WordIdentifier", "class_word_identifier.html#a6c6333254a39a039c8fe00989e5f2b52", null ],
    [ "~WordIdentifier", "class_word_identifier.html#aacefe243e4a07ee39f67986fd56f5f1b", null ],
    [ "WordGuesser", "class_word_identifier.html#ada488498c9757ab7f93db6d0e5d66913", null ],
    [ "WordPosition", "class_word_identifier.html#a5cb9a5381c3e79a93b8ad4fb6d0f7722", null ]
];