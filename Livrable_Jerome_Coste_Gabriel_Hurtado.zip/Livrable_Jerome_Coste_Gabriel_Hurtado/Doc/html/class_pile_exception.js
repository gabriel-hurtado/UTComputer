var class_pile_exception =
[
    [ "PileException", "class_pile_exception.html#ae7e15aad42d0aad18b35e867d4d05d70", null ],
    [ "getInfo", "class_pile_exception.html#a58045a43618bbd52db674bb363dc9577", null ],
    [ "what", "class_pile_exception.html#a29970db5c81c812c3ec2963784d72e11", null ]
];