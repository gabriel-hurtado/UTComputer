var searchData=
[
  ['variablesmanager',['VariablesManager',['../class_variables_manager.html',1,'']]]
];
