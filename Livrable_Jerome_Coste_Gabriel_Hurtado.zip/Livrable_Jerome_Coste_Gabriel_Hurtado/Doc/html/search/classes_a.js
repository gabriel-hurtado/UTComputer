var searchData=
[
  ['selectedposition',['SelectedPosition',['../struct_selected_position.html',1,'']]]
];
