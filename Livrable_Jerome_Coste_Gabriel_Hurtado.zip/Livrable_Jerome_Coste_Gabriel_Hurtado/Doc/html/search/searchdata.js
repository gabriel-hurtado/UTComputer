var indexSectionsWithContent =
{
  0: "acefgilmnoprstuvw~",
  1: "acegilmoprsvw",
  2: "acefgimnoprstu~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

