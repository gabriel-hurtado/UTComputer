var searchData=
[
  ['wordidentifier',['WordIdentifier',['../class_word_identifier.html',1,'']]]
];
