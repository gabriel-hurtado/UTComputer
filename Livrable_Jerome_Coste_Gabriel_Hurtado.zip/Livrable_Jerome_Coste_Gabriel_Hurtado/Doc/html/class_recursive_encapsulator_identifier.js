var class_recursive_encapsulator_identifier =
[
    [ "RecursiveEncapsulatorIdentifier", "class_recursive_encapsulator_identifier.html#a572dab330c04b9e5c0b726adb89810c2", null ],
    [ "setLeftDelimiter", "class_recursive_encapsulator_identifier.html#a60c6ee5e949c9a4f05e650033930522f", null ],
    [ "setRightDelimiter", "class_recursive_encapsulator_identifier.html#a44bae9023dc049f8b60d84fff7a796ce", null ],
    [ "WordGuesser", "class_recursive_encapsulator_identifier.html#a55dfc32b04d600573054d068cf8706c7", null ],
    [ "WordPosition", "class_recursive_encapsulator_identifier.html#ae5a3166084000b6198a7cb60b19db030", null ]
];