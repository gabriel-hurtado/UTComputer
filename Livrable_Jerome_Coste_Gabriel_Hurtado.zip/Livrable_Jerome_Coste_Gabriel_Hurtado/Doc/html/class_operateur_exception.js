var class_operateur_exception =
[
    [ "OperateurException", "class_operateur_exception.html#a46872c3ab4bbed795aa6fe7bad1697e5", null ],
    [ "getInfo", "class_operateur_exception.html#a16dc872f9d6bb34f5ac757501d8ca1d4", null ],
    [ "what", "class_operateur_exception.html#a4c88d610ba776394ea78e7d50d9e2c64", null ]
];