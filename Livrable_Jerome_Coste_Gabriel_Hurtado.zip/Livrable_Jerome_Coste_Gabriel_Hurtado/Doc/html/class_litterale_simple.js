var class_litterale_simple =
[
    [ "LitteraleSimple", "class_litterale_simple.html#aec130b6d94b97be41242385ff4e9c39b", null ],
    [ "~LitteraleSimple", "class_litterale_simple.html#a728c27128c4f72ce9368055f700d8f38", null ]
];