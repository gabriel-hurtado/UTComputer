var class_operateur_prefixe =
[
    [ "~OperateurPrefixe", "class_operateur_prefixe.html#ae7e0f84d175785da8ec7b0dc039db36d", null ],
    [ "getCopy", "class_operateur_prefixe.html#a0e3cbbfc4fd293fef8e5bd2152f6f5c9", null ]
];