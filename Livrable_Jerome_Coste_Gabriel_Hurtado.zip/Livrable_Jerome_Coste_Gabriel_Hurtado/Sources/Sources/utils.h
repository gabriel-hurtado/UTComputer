#ifndef H_UTILS
#define H_UTILS

int pgcd(int a, int b);
#endif
